package grid.library;

import processing.core.*;

/**
 * This is a template class and can be used to start a new processing Library.
 * Make sure you rename this class as well as the name of the example package 'template' 
 * to your own Library naming convention.
 * 
 * (the tag example followed by the name of an example included in folder 'examples' will
 * automatically include the example in the javadoc.)
 *
 * @example Hello 
 */

public class Grid {
	
	PApplet parent;
	boolean showGrid = true; 
	boolean showHorizontal = true; 
	boolean showVertical = true; 
	boolean showRadial = false; 
	boolean showAngular = false; 
	boolean useThicknessVariation = true; 
	float gridLineBaseThickness = (float)0.5;
	float gridLineBigThickness = (float)(3*0.5);
	float gridInterval = (float)10; 
	float gridRadialInterval = (float)Math.sqrt(2)*gridInterval;
	float gridAngularInterval = (float)45/2;
	float gridStrokeAlpha = (float)50; 
	int gridLineColor = 0;
	int gridRadialSpacing = 5;
	
	
	public final static String VERSION = "1.0.0";

	/**
	 * a Constructor, usually called in the setup() method in your sketch to
	 * initialize and start the Library.
	 * 
	 * @example Hello
	 * @param theParent the parent PApplet
	 */
	public Grid(PApplet theParent) {
		parent = theParent;
	}
	
	public void drawGrid() {
		if (showGrid) {
			parent.resetMatrix();
			// Helpers 
			int count = 0; 
			// Get display width, height
			int height = parent.height; 
			int width = parent.width; 
			// Set grid line color 
			parent.stroke(gridLineColor, gridStrokeAlpha); 
			// Draw horizontal lines 
			if (showHorizontal) {
				for(int yval = 0; yval < height; yval += gridInterval) {
					if (count != 0 && count%10 == 0) {
						parent.strokeWeight(gridLineBigThickness);
					} else {
						parent.strokeWeight(gridLineBaseThickness);
					}
					count++;
					parent.line(0, yval, width, yval);
				}
					
			}
			// Draw vertical lines 
			if (showVertical) {
				count = 0; 
				for(int xval = 0; xval < width; xval += gridInterval) {
					if (count != 0 && count%10 == 0) {
						parent.strokeWeight(gridLineBigThickness);
					} else {
						parent.strokeWeight(gridLineBaseThickness);
					}
					count++;
					parent.line(xval, 0, xval, height);
				}
			}
			// Draw radials 
			if (showRadial) {
				count = 0;
				parent.translate(width/2, height/2);
				parent.noFill();
				parent.strokeWeight(gridLineBaseThickness);
				float rlimit = (float)1.5*Math.max(height, width);
				for(float rval = 0; rval < rlimit; rval += gridRadialInterval) {
					if (count%gridRadialSpacing == 0)
						parent.circle(0, 0, rval);
					count++;
				}
				parent.resetMatrix();
			}
			// Draw angular lines
			if (showAngular) {
				count = 0; 
				parent.translate(width/2, height/2);
				parent.strokeWeight(gridLineBaseThickness);
				float rlimit = (float)1.5*Math.max(height, width);
				for(float deg = 0; deg < 360; deg += gridAngularInterval) {
					float rdeg = (float)Math.toRadians(deg);
					float x = (float)Math.cos(rdeg)*rlimit;
					float y = (float)Math.sin(rdeg)*rlimit;
					parent.line(0, 0, x, y);
				}
				parent.resetMatrix();
			}
		}
	}
	
	public void setShowGridTo(boolean _showGrid) {
		showGrid = _showGrid; 
	}
	
	public void setShowHorizontalTo(boolean _showHorizontal) {
		showHorizontal = _showHorizontal; 
	}
	
	public void setShowVerticalTo(boolean _showVertical) {
		showVertical = _showVertical; 
	}
	
	public void setShowRadialTo(boolean _showRadial) {
		showRadial = _showRadial; 
	}
	
	public void setShowAngularTo(boolean _showAngular) {
		showAngular = _showAngular;
	}
	
	public void setUseThicknessVariationTo(boolean _useThicknessVariation) {
		useThicknessVariation = _useThicknessVariation; 
		if (useThicknessVariation)
			gridLineBigThickness = (float)3*gridLineBaseThickness;
		else 
			gridLineBigThickness = gridLineBaseThickness; 
	}
	
	public void setGridLineColorTo(int _gridLineColor) {
		gridLineColor = _gridLineColor; 
	}
	
	public void setGridStrokeAlphaTo(float _gridStrokeAlpha) {
		gridStrokeAlpha = _gridStrokeAlpha;
	}
	
	public void setGridLineBaseThicknessTo(float _gridLineBaseThickness) {
		gridLineBaseThickness = _gridLineBaseThickness; 
	}
	
	public void setGridRadialSpacingTo(int _gridRadialSpacing) {
		gridRadialSpacing = _gridRadialSpacing; 
	}
	
	public void setGridIntervalTo(int _gridInterval) {
		gridInterval = _gridInterval; 
	}
	
	public void setGridAngularIntervalTo(float _gridAngularInterval) {
		gridAngularInterval = _gridAngularInterval; 
	}
	
	public void setUseXYTo(boolean _useXY) {
		if (_useXY) {
			showHorizontal = true; 
			showVertical = true; 
		} else {
			showHorizontal = false; 
			showVertical = false;
		}
	}
	
	public void setUseRadialTo(boolean _useRadial) {
		if (_useRadial) {
			showRadial = true; 
			showAngular = true;
		} else {
			showRadial = false; 
			showAngular = false; 
		}
	}
	
}